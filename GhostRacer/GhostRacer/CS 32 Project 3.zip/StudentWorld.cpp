#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <iostream>
using namespace std;

const int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
const int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
	m_whiteY = 0;
	m_player = nullptr;
}

int StudentWorld::init()
{
	m_player = new GhostRacer(this);
	int N = VIEW_HEIGHT / SPRITE_HEIGHT;
	
	for (int j = 0; j < N; j++)
	{
		m_actor.push_back(new YellowBorder(LEFT_EDGE*1.0, j * (double)SPRITE_HEIGHT, this));
		m_actor.push_back(new YellowBorder(RIGHT_EDGE*1.0, j * (double)SPRITE_HEIGHT, this));
	}
	int M = VIEW_HEIGHT / (4*SPRITE_HEIGHT);
	for (int j = 0; j < M; j++)
	{
		m_actor.push_back(new WhiteBorder(LEFT_EDGE + ROAD_WIDTH/3.0, j * 4.0 * SPRITE_HEIGHT, this));
		m_actor.push_back(new WhiteBorder(RIGHT_EDGE - ROAD_WIDTH/3.0, j * 4.0 * SPRITE_HEIGHT, this));
	}
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{

	for (unsigned int i = 0; i < m_actor.size(); i++)
	{
		if (m_actor[i]->isActorAlive())
		{
			m_actor[i]->doSomething();
			if (!getPlayer()->isActorAlive())
			{
				delete m_player;
				return GWSTATUS_PLAYER_DIED;
			}
		}
	}

	m_player->doSomething(); 
	if (!getPlayer()->isActorAlive())
	{
		delete m_player;
		return GWSTATUS_PLAYER_DIED;
	}

	for (unsigned int i = 0; i < m_actor.size(); i++)
	{
		if (!m_actor[i]->isActorAlive())
		{
			delete m_actor[i];
			m_actor.erase(m_actor.begin() + i);
			i--;
		}
	}
	double new_border_y = VIEW_HEIGHT*1.0 - SPRITE_HEIGHT*1.0;

	double borderSpeed = (-4) - (getPlayer()->getSpeed());
	setWhiteY(getWhiteY() + borderSpeed);

	double delta_y = new_border_y - getWhiteY();
	if (delta_y >= SPRITE_HEIGHT*1.0)
	{
		m_actor.push_back(new YellowBorder(ROAD_CENTER*1.0 - ROAD_WIDTH / 2.0, new_border_y, this));
		m_actor.push_back(new YellowBorder(ROAD_CENTER*1.0 + ROAD_WIDTH / 2.0, new_border_y, this));
	}
	if (delta_y >= 4.0 * SPRITE_HEIGHT)
	{
		m_actor.push_back(new WhiteBorder(ROAD_CENTER*1.0 - ROAD_WIDTH / 2.0 + ROAD_WIDTH / 3.0, new_border_y, this));
		m_actor.push_back(new WhiteBorder(ROAD_CENTER*1.0 + ROAD_WIDTH / 2.0 - ROAD_WIDTH / 3.0, new_border_y, this));
	}
	return GWSTATUS_CONTINUE_GAME;
}
