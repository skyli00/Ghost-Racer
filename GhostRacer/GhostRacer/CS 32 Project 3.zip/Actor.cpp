
#include "StudentWorld.h"
#include <iostream>
using namespace std;
bool isinBound(double x, double y)
{
	return (x >= 0 && x <= VIEW_WIDTH*1.0) && (y >= 0 && y <= VIEW_HEIGHT*1.0);
}
void GhostRacer::doSomething()
{
	if (healthLevel() <= 0)
		setAliveStatus(false);
	if (!isActorAlive())
	{
		return;
	}
	double x = getX();
	double y = getX();
	if (x - 10 <= ROAD_CENTER - ROAD_WIDTH / 2.0)//left Border
	{
		if (getDirection() > 90)
			takeDamage(10);//hit the wall, take damage
		setDirection(82);//Change direction
	}

	if (y + 10 >= ROAD_CENTER + ROAD_WIDTH / 2.0)//right Border
	{
		if (getDirection() < 90)
			takeDamage(10);//hit the wall, take damage
		setDirection(98);//Change direction
	}



	//check input
	int ch;
	if (getWorld()->getKey(ch))
	{
		// user hits a key during this tick
		switch (ch)
		{
		case KEY_PRESS_RIGHT://turn right
			if (getDirection() > 66)
				setDirection(getDirection() - 8);
			break;
		case KEY_PRESS_LEFT://turn left
			if (getDirection() < 114)
				setDirection(getDirection() + 8);
			break;
		case KEY_PRESS_DOWN://slow down
			if (getSpeed() > -1 )
				setSpeed(getSpeed() - 1);
			break;
		case KEY_PRESS_UP://accelerate
			if (getSpeed() < 5)
				setSpeed(getSpeed() + 1);
			break;
		//case KEY_PRESS_SPACE:
			//WaterSpray* spray = new WaterSpray;
			//break;
		}
	}


	//move the ghost racer according to direction
	double max_shift_per_tick = 4.0;
	double direction = getDirection();
	double delta_x = cos(direction * 3.14 / 180) * max_shift_per_tick;
	double cur_x = getX();
	double cur_y = getY();
	moveTo(delta_x + cur_x, cur_y);
}
void Border::doSomething()
{
	double vert_speed = getVertiSpeed() - getWorld()->getPlayer()->getSpeed();
	double horiz_speed = getHorizSpeed();
	double new_y = getY() + vert_speed;
	double new_x = getX() + horiz_speed;
	moveTo(new_x, new_y);
	if (!isinBound(new_x, new_y))
	{
		setAliveStatus(false);
		return;
	}
}

WhiteBorder::WhiteBorder(double x, double y, StudentWorld* swp) :
	Border(IID_WHITE_BORDER_LINE, x, y,
		0, 2.0, 2, swp)
{
	getWorld()->setWhiteY(y);
}

