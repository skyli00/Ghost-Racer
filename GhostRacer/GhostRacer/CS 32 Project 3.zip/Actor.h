#ifndef ACTOR_H_
#define ACTOR_H_


#include "GraphObject.h"

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(const int imageID, double startX,
		double startY, int startDirection,
		double size, int depth, StudentWorld* swp) :GraphObject(imageID, startX, startY,
			startDirection, size, depth)
	{
		m_alive = true;
		setWorld(swp);
	}

	//virtual void move() = 0;
	void setAliveStatus(bool alive) { m_alive = alive; }
	virtual int getWhiteBorder() {return 255;};
	virtual void doSomething() = 0;
	StudentWorld* getWorld() {return m_theWorld; }
	void setWorld(StudentWorld* swp) { m_theWorld = swp; }
	bool isActorAlive() { return m_alive; }
private:
	StudentWorld* m_theWorld;
	bool m_alive;
};

class Pedestrain : public Actor
{
public:
	Pedestrain(const int imageID, double startX,
		double startY, int startDirection,
		double size, int depth, int health, StudentWorld* swp): 
		Actor(imageID, startX, startY,
			startDirection, size, depth, swp) 
	{
		m_health = health;
	}
	int healthLevel() 
	{ return m_health; }

	void takeDamage(int hurt) 
	{
		m_health -= hurt;
		if (healthLevel() <= 0)
			setAliveStatus(false);
	}
private:
	int m_health;
};


class GhostRacer : public Pedestrain
{
public:
	GhostRacer(StudentWorld* swp) :Pedestrain
		(IID_GHOST_RACER, 128, 32,90, 4.0, 0, 100, swp)
	{
		setAliveStatus(true);
		m_ammo = 10;
		m_vertSpeed = 0;
	}
	double getSpeed() { return m_vertSpeed; }
	void setSpeed(double newSpeed) { m_vertSpeed = newSpeed; }
	virtual void doSomething();
private:
	int m_ammo;
	double m_vertSpeed;
};

class Border :public Actor 
{
public:
	Border(const int imageID, double startX,
		double startY, int startDirection,
		double size, int depth, StudentWorld* swp) :
		Actor(imageID, startX, startY,
			startDirection, size, depth, swp)
	{
		setAliveStatus(true);
		setVertiSpeed(-4);
		setHorizSpeed(0);
	}
	void setVertiSpeed(double speed) { m_vertiSpeed = speed; }
	void setHorizSpeed(double speed) { m_horizSpeed = speed; }

	double getVertiSpeed() { return m_vertiSpeed; }
	double getHorizSpeed() { return m_horizSpeed; }
	virtual void doSomething();
private:
	double m_vertiSpeed;
	double m_horizSpeed;
};

class WhiteBorder :public Border
{
public:
	WhiteBorder(double x, double y, StudentWorld* swp);
private:

};

class YellowBorder : public Border
{
public:YellowBorder(double x, double y, StudentWorld* swp) :
	Border(IID_YELLOW_BORDER_LINE, x, y,
		0, 2.0, 2, swp)
{
}
private:
};



#endif // ACTOR_H_
