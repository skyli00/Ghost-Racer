#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    virtual int init();
    virtual int move();
    virtual void cleanUp() 
    {
        for (unsigned int i = 0; i < m_actor.size(); i++)
        {
            delete m_actor[i];
            m_actor.erase(m_actor.begin());
            i--;
        }
    }
    GhostRacer* getPlayer() { return m_player; }
    double getWhiteY() { return m_whiteY; }
    void setWhiteY(double newY) { m_whiteY = newY; }
    ~StudentWorld()
    {
        cleanUp();
    }
private:

    std::vector <Actor*> m_actor;
    GhostRacer* m_player;
    double m_whiteY;
};

#endif // STUDENTWORLD_H_